For historical reasons the files in this folder use the following mark-up notation, which is slightly different from that introduced in the text of the paper. We provide the notation of the paper in the breckets;

0. Homonymy or coincidence [type 5 in the main text]. 

1. City or city dwellers [type 1 in the main text].

2. Vicinity of the city and entities in this vicinity [type 3 in the main text].

3. Entities located in the city and named after it [type 2 in the main text].

4. Entities located elsewhere but named after the city [type 4 in the main text]. 